#include <iostream>
#include <Windows.h>
#include <shellapi.h>

#define WM_MYMESSAGE (WM_USER + 1)

bool isWindowHidden = false;

int main()
{
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	NOTIFYICONDATA nid;
	nid.cbSize = sizeof(NOTIFYICONDATA);
	nid.hWnd = GetConsoleWindow();
	nid.uID = 100;
	nid.uVersion = NOTIFYICON_VERSION;
	nid.uCallbackMessage = WM_MYMESSAGE;
	nid.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	if (!Shell_NotifyIconA(NIM_ADD, &nid))
	{
		MessageBox(0, "Failed to mount to System Tray.", "Strayfade ProgramHider", MB_OK);
	}
	HWND hiddenWindow = NULL;
	while (!GetAsyncKeyState(VK_INSERT))
	{
		if (GetAsyncKeyState(0xDC) & 1)
		{
			if (!isWindowHidden)
			{
				hiddenWindow = GetForegroundWindow();
				ShowWindow(hiddenWindow, SW_HIDE);
				isWindowHidden = !isWindowHidden;
			}
			else if (isWindowHidden)
			{
				ShowWindow(hiddenWindow, SW_SHOW);
				isWindowHidden = !isWindowHidden;
			}
			Sleep(500);
		}
	}
}